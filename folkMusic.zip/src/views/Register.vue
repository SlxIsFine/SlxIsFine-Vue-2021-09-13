<template>
    <iframe src="/login/zhuce.html" frameborder="0" style="width:100vw;height:100vh"></iframe>
</template>
<script setup>

</script>