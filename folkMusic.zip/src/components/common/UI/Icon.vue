<template>
  <i :class="className" :style="style">
    {{ it }}
  </i>
</template>
<script setup>
import { computed, defineProps } from "vue";
//icon-class icon-text 任选其一,w,h宽高
let { ic, it, w, h, mg, color } = defineProps(["ic", "it", "w", "h", "mg", "color"]);
let className = computed(() => {
  let base = "iconfont icontent ";
  if (ic) return base + `icon-${ic}`;
  return base;
});
let style = computed(() => {
  return {
    width: w,
    height: h || "max-content",
    margin: mg,
    fontSize: w,
    color: color,
  };
});
</script>

<style lang="scss" scoped>
@import "./Icons.scss";
 .icontent {
  display: inline-block;
  vertical-align: middle;
}
</style>
