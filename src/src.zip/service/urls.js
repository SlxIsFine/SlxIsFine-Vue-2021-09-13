const baseUrl = "http://47.93.3.182:8080/api/v1"
const user =baseUrl+ "/user/"
const goods = baseUrl+ "/goods/"
const captcha=baseUrl+"/captcha/"
export default {
    //用户接口
    user: {
        checkUserName: user + "check/checkName", // 检查用户名是否合法
        checkEmail:user+"check/checkEmail",//验证邮箱可用且未被注册
        verifyEmail:user+"check/verifyEmail",//验证邮箱验证码
        checkPhone:user+"check/checkPhone",//验证手机号
        verifyPhone:user+"check/verifyPhone",//验证手机验证码
        checkReal:user+"check/checkReal",//实名验证
        byPassword:user+"/ByPassword",//账号密码注册
        byWeChat:user+"/ByWeChat",//微信注册，开发中
    },
    // 商品接口
    goods: {

    },
    // 验证码接口
    captcha:{
        getCaptcha:captcha+"/getCaptcha",
        verifyCaptcha:captcha+"verifyCaptcha"

    }


}